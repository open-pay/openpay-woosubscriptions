=== Openpay WooSubscriptions Plugin ===
Contributors: openpay
Tags: payment gateway, openpay, subscriptions 
Requires at least: 4.8
Tested up to: 5.7
Requires PHP: 5.6
Stable tag: 3.1.2
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

WooSubscriptions Plugin for Openpay API services

== Installation ==
For more information about this module go to: 

http://www.openpay.mx/docs/plugins/woosubscriptions.html

== Changelog ==
= 3.1.2 =
Fix. Error de conexión Openpay Colombia Producción
= 3.1.1 =
Fix. Reintento de subscripción al fallar pago. (Actualizar parámetros para futuras subscripciones)
= 3.1.0 =
* Enhancement. Unificación del plugin para procesar pagos México/Colombia
= 3.0.0 =
* Enhancement. Compatibilidad con la nueva versión de Woocommerce Subscriptions (Se agrega funcionalidad para el cambio de tarjeta por el cliente)