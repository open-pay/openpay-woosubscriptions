# openpay-woosubscriptions
Plugin para módulo de suscripciones de WooCommerce, compatible con la versión 1.5.x
